# SwaggerClient::DefaultApi

All URIs are relative to *https://stackoverflowapitest.herokuapp.com/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**posts_get**](DefaultApi.md#posts_get) | **GET** /posts | Search posts on Stackoverflow


# **posts_get**
> Array&lt;Post&gt; posts_get(query)

Search posts on Stackoverflow

Search the site for questions using most of the on-site search options.

### Example
```ruby
# load the gem
require 'swagger_client'

api_instance = SwaggerClient::DefaultApi.new

query = "query_example" # String | Search query


begin
  #Search posts on Stackoverflow
  result = api_instance.posts_get(query)
  p result
rescue SwaggerClient::ApiError => e
  puts "Exception when calling DefaultApi->posts_get: #{e}"
end
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **query** | **String**| Search query | 

### Return type

[**Array&lt;Post&gt;**](Post.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json



