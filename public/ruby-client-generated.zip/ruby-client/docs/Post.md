# SwaggerClient::Post

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **String** | Question title | [optional] 
**link** | **String** | Question link | [optional] 


